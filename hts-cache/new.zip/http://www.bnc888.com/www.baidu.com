﻿<!DOCTYPE html>
<html>
<script type="text/javascript">
    // window.location.replace(window.location.protocol+'//'+window.location.host);
</script>
<head>
    <meta charset="UTF-8">
    <meta name="author" content="网站建设：互诺科技 - http://www.hunuo.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="format-detection" content="telephone=no, email=no" />
    <title>404</title>
    <style>
    	body{background-color: #fff;min-width: 0;}
    	.er-main{text-align: center;width: 100%;overflow: hidden;}
	    .er-shadow{height:180px}
		.er-shadow2{width:130px}
		.er-shadow1,
		.er-shadow3{width:250px}
		.er-tip{font-size:32px}
		.er-msg{top:-190px;left:30%;width:80px;height:80px;line-height:80px;font-size:32px}
		.er-tri{top:70%;right:0%;border-left:20px solid #535353;border-top:15px solid transparent;border-bottom:15px solid transparent}
		.er-box{margin-top:10%;position:relative;height:250px;padding-top:40px}
		.er-clip{display:inline-block;transform:skew(-45deg)}
		.er-shadow{overflow:hidden}
		.er-shadow2{overflow:hidden;position:relative;box-shadow:inset 20px 0px 20px -15px rgba(150,150,150,0.8),20px 0px 20px -15px rgba(150,150,150,0.8)}
		.er-shadow3:after,
		.er-shadow1:after{content:"";position:absolute;right:-8px;bottom:0px;z-index:9999;height:100%;width:10px;background:linear-gradient(90deg,transparent,rgba(173,173,173,0.8),transparent);border-radius:50%}
		.er-shadow3:after{left:-8px}
		.er-digit{width:150px;height:150px;line-height:150px;font-size:120px;font-weight:bold;text-align: center;position:relative;top:8%;color:white;background:#0d6efd;border-radius:50%;display:inline-block;transform:skew(45deg)}
		.er-digit2{left:-10%}
		.er-digit1{right:-20%}
		.er-digit3{left:-20%}
		.er-tip{font-size:24px;color:#A2A2A2;font-weight:bold;padding-bottom:20px}
		.er-tohome{font-size:16px;color:#0d6efd}
		.er-msg{position:relative;z-index:9999;display:block;background:#535353;color:#A2A2A2;border-radius:50%;font-style:italic}
		.er-tri{position:absolute;z-index:999;transform:rotate(45deg);content:"";width:0;height:0}
		@media(max-width:767px){
			.er-shadow{height:100px}
			.er-shadow2{width:80px}
			.er-shadow1,
			.er-shadow3{width:100px}
			.er-digit{width:80px;height:80px;line-height:80px;font-size:52px}
			.er-tip{font-size:16px}
			.er-msg{top:-110px;left:15%;width:40px;height:40px;line-height:40px;font-size:18px}
			.er-tri{top:70%;right:-3%;border-left:10px solid #535353;border-top:8px solid transparent;border-bottom:8px solid transparent}
			.er-box{height:150px}
		}
    </style>
</head>
<body>
    <div class="er-main">
        <div class="er-box">
            <div class="er-clip">
                <div class="er-shadow er-shadow1">
                    <span class="er-digit er-digit1">4</span>
                </div>
            </div>
            <div class="er-clip">
                <div class="er-shadow er-shadow2">
                    <span class="er-digit er-digit2">0</span>
                </div>
            </div>
            <div class="er-clip">
                <div class="er-shadow er-shadow3">
                    <span class="er-digit er-digit3">4</span>
                </div>
            </div>
            <div class="er-msg">OH!
                <span class="er-tri"></span>
            </div>
        </div>
        <h2 class="er-tip">对不起, 您访问的页面无法找到</h2>
        <p>
            <a class="er-tohome" href="/">返回首页</a>
            <!--<a class="er-tohome" href="javascript:history.go(-1)">返回上一页</a>-->
        </p>
    </div>
</body>

</html>
<script src="/static/admin/js/jquery.js"></script>

<script>
$(function() {
	function randomNum() {
	    return Math.floor(Math.random() * 9) + 1;
	}
	var loop1, loop2, loop3,
	    time = 30, i = 0, number;
	loop3 = setInterval(function () {
	    if (i > 40) {
	        clearInterval(loop3);
	        document.querySelector('.er-digit1').textContent = 4;
	    } else {
	        document.querySelector('.er-digit1').textContent = randomNum();
	        i++;
	    }
	}, time);
	loop2 = setInterval(function () {
	    if (i > 80) {
	        clearInterval(loop2);
	        document.querySelector('.er-digit2').textContent = 0;
	    } else {
	        document.querySelector('.er-digit2').textContent = randomNum();
	        i++;
	    }
	}, time);
	loop1 = setInterval(function () {
	    if (i > 100) {
	        clearInterval(loop1);
	        document.querySelector('.er-digit3').textContent = 4;
	    } else {
	        document.querySelector('.er-digit3').textContent = randomNum();
	        i++;
	    }
	}, time);
	})
</script>